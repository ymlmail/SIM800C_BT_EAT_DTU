//yemaolin Creat 2015-7-29
#if defined(__SIMCOM_PROJ_SIM800W__)
  //SIM800W only have one ADC
  #define EAT_ADC0 EAT_PIN6_ADC0
  #define EAT_ADC1 EAT_PIN6_ADC0
#elif defined __SIMCOM_PROJ_SIM800V__
  //SIM800V have two ADC
  #define EAT_ADC0 EAT_PIN9_ADC0
  #define EAT_ADC1 EAT_PIN5_ADC1
#elif defined __SIMCOM_PROJ_SIM800H__
  //SIM800H only have one ADC
  #define EAT_ADC0 EAT_PIN50_ADC
  #define EAT_ADC1 EAT_PIN50_ADC
#elif defined __SIMCOM_PROJ_SIM800__
  //SIM800 only have one ADC
  #define EAT_ADC0 EAT_PIN25_ADC
  #define EAT_ADC1 EAT_PIN25_ADC
#elif defined __SIMCOM_PROJ_SIM800C__
  //SIM800C only have one ADC
  #define EAT_ADC0 EAT_PIN38_ADC
  #define EAT_ADC1 EAT_PIN38_ADC
#endif

#define DebugMsgOnOff		1

#define UsbAsPort			0


#define SeverDataMax		100






