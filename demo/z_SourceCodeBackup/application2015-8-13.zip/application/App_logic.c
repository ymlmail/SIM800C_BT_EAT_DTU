
#include "App_include.h"

void Ask_ModuleLBSmsg(void);

eat_bool DecodeSeverData(void);
#if 0
void AppGetEventHandle(void)
{
    EatEvent_st event;
    u16 len = 0;
    eat_get_event(&event);
    eat_trace("MSG id%x", event.event);
    switch(event.event)
    {
        case EAT_EVENT_TIMER :
            {
                //Restart timer
                if(event.data.timer.timer_id==EAT_TIMER_1)
                	{
                	flag.timer1up =1;		//timer1 ʱ�䵽
					eat_timer_start(event.data.timer.timer_id, 1000);
					eat_trace("Timer1 is up, timer ID:%d", event.data.timer.timer_id);
                	}
				else
					{
					eat_timer_start(event.data.timer.timer_id, 3000);
					eat_trace("other Timer's up, timer ID:%d", event.data.timer.timer_id);
					}
                
            }
            break;
        case EAT_EVENT_MDM_READY_RD:
            {
                u8 param1,param2;
                len = 0;
                len = eat_modem_read(buf, 2048);
                if(len > 0)
                {	//eat_trace("HELLO TEST11\n");
                    //Get the testing parameter
                    if(eat_modem_data_parse(buf,len,&param1,&param2))//���Ƿ�Ϊ����
                    {
                        //Entry timer test module
                        //eat_module_test_timer(param1, param2);
                    }
                    else	//������ǲ�����������Ĵ�����
                    {
                        eat_trace("From Mdm:%s",buf);
                    }
                }
				else
				{
				#if DebugMsgOnOff
                eat_trace("EAT_EVENT_MDM_READY_RD occur,but buf");
				#endif
					}

            }
            break;
        case EAT_EVENT_MDM_READY_WR:
        case EAT_EVENT_UART_READY_RD:
			eat_trace("HELLO TEST222\n");
            break;
        case EAT_EVENT_UART_SEND_COMPLETE :
            break;
        default:
            break;
    }
}
#endif
void AppLogicHandle(void)
{
u8 counter=0;
  if(flag.timer1up)
  	{
  	counter++;
  	}
  if(counter>=200)
  	{
	TRACE_DEBUG("count=%d",counter);
  	counter=0;
  	}
  TRACE_DEBUG("flag.recvSeverData=%d",flag.recvSeverData);
 // Delayms(500);
  //flag.recvSeverData=1;

  if(flag.recvSeverData)
  	{
  	flag.recvSeverData=0;
	DecodeSeverData();
  	}

}

eat_bool DecodeSeverData(void)
	{
	#if 1
	eat_bool ret_val = EAT_FALSE;
	u8 i;
	u16 msgLen=0;			//��Ϣ�ĳ���
	//u16 msgStartMark=0x0000;
	u16 crc16=0,datacrc16=0;
	u16 datacrc1=0,datacrc2=0;

	u8 ProtocolNumber=0;
	
	for(i=0;i<g_RecvServerDataLen;i++)
		{
		//Read from Server.TODO something
		//eat_trace("Recv data 0x=%x",buf[i]);
		eat_trace("R222 data 0x=%x",g_RecvServerData[i]);
		}

	//msgStartMark=g_RecvServerData[0];
	//msgStartMark=(msgStartMark<8)|g_RecvServerData[1];
	if(g_RecvServerData[0]==0x78&&g_RecvServerData[0]==0x78)
		{
		TRACE_DEBUG("msgStartMark==0x7878\n");
		}
	else
		{
		TRACE_DEBUG("ERRO msgStartMark==0x%x,0x%x\n",g_RecvServerData[0],g_RecvServerData[1]);
		//return ret_val;
		}
	
	msgLen=g_RecvServerData[2];

	datacrc1=g_RecvServerData[g_RecvServerDataLen-4];
	datacrc2=g_RecvServerData[g_RecvServerDataLen-3];
	datacrc16=(datacrc1<<8)|datacrc2;
	
	crc16=GetCrc16((const u8*)g_RecvServerData+2,msgLen-1);
	if (datacrc16==crc16)
		{
		TRACE_DEBUG("CRC ok\n");
		}
	else
		{
		TRACE_DEBUG("CRC NG\n");
		//return ret_val;
		}
	#if DebugMsgOnOff
	TRACE_DEBUG("GetCrc16 crc16=0x%x,0x%x",datacrc16,crc16);
	TRACE_DEBUG("data lenth is msgLen=%x",msgLen);
	#endif

	
	ProtocolNumber=g_RecvServerData[3];	//��Э��Ÿ���ʱ����

	switch(ProtocolNumber)
	{
		case LoginMsgNUM :
			flag.LoginOK=1;//��ɳɹ�
			TRACE_DEBUG("++++register server ok!!!++++\n");
			break;
		case LBSMsgNUM:
			//flag.LBSmsgReady=1;
			flag.reportLBSmsgOK=1;
			TRACE_DEBUG("++++LBSMsg report msg ok!!!++++\n");
			break;

		default:
			break;
	}
	
	ret_val=EAT_TRUE;
	return ret_val;
	#endif
	}

void Ask_ModuleLBSmsg(void)
{	
	eat_modem_write("AT+CREG?\n",strlen("AT+CREG?\n"));
}
void SetCregValue(void)// �Զ��ϱ�CREG״̬
{
eat_modem_write("AT+CREG=2\n",strlen("AT+CREG=2\n"));
eat_sleep(50);
}
void SetCENGValue(void)//����ģʽ����
{
eat_modem_write("AT+CENG=3,0\n",strlen("AT+CENG=3,0\n"));
eat_sleep(50);
}

