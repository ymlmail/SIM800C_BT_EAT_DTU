#ifndef _APP_RAM_C
#define _APP_RAM_C
#include "App_ram.h"

T_FLAG  flag;
T_DELAY delay;
T_KEY   key;

u8 g_CounterSec=0;


u8 buf[2048];
u8 g_imei_sn[16]={0};
u8 g_RecvServerData[100]={0};
u8 g_RecvServerDataLen=0;

Info_LBS LBSmsg;
Info_Logoin logoinInfo;
EatRtc_st rtc = {0};

LAC_TYPE LocationAreaCode;//LAC
CI_TYPE CellID;				//CI
u8	g_MobileNetworkCode=0;

u16 g_loginMsgSn=0;
u8 g_sendDataArry[200];

#endif
