/********************************************************************
 *                Copyright Simcom(shanghai)co. Ltd.                   *
 *---------------------------------------------------------------------
 * FileName      :  app_custom.c
 * version       :   0.10
 * Description   :   
 * Authors       :   heweijiang
 * Notes         :
 *---------------------------------------------------------------------
 *
 *    HISTORY OF CHANGES
 *---------------------------------------------------------------------
 *0.10  2014-07-11, heweijiang, create originally.
 *
 ********************************************************************/
/********************************************************************
 * Include Files
 ********************************************************************/
#include "app_custom.h"
#include "App_include.h"

/********************************************************************
* Macros
 ********************************************************************/

/********************************************************************
* Types
 ********************************************************************/
 
/********************************************************************
* Extern Variables (Extern /Global)
 ********************************************************************/

/*Customer configuration*/
ModemConfigContext g_modemConfig =
{
    "CMET",             /*apnName*/
    "",                 /*apnUserName*/
    "",                 /*apnPassword*/
    "116.247.119.165",  /*FTPServerIP*/
    "admin",            /*FTPUserName*/
    "password",         /*FTPPassword*/
    "filename",         /*FTPFileName*/
    "/",                /*FTPFilePath*/
    21,                 /*FTPPort*/
};

const SIMCOM_SMS_INFO g_sms_info = 
{
    TEXT,			//TEXTģʽֻ�ܷ��ַ������ܷ�����????
    "",             //sc number
    "13320984483",  //phone number
    "0123456789jason",   //message string
    15,             //message length
    1
};
/*
const SIMCOM_SMS_INFO g_sms_info = 
{
    PDU,
    "",             //sc number
    "13320984483",  //phone number
    "01Ҷï��00",   //message string
    10,             //message length
    1
};*/

/********************************************************************
* Local Variables:  STATIC
 ********************************************************************/

/********************************************************************
* External Functions declaration
 ********************************************************************/

/********************************************************************
* Local Function declaration
 ********************************************************************/
 
/********************************************************************
* Local Function
 ********************************************************************/
    
void GsmInitCallback(eat_bool result)
{
    if (result)
    {
        //GSM Init ok, to do something. 
        eat_trace("GSM init OK\r\n",14);
        simcom_tcpip_test();
    }
    else
    {
        eat_trace("GSM init ERROR\r\n",14);        
    }
}

void askCregCallback(eat_bool result)
{
    if (result)
    {
        //GSM Init ok, to do something. 
        eat_trace("1212121\r\n",14);
    }
    else
    {
        eat_trace("@@@@@@@@\r\n",14);        
    }
}
static void app_timer3_handler(void)
{
  u32 voltage;

  if(flag.timer3up)
  {
  	flag.timer3up=0;
  	g_CounterSec++;
	eat_trace("timer3up 1 minute\n");
  if(g_CounterSec>=3)
  	{
	//TRACE_DEBUG("g_CounterSec=%d",g_CounterSec);
	eat_get_adc_sync(EAT_ADC0 ,&voltage);
	eat_trace("ADC test 5,adc [%d]",voltage);//��Χ��0-2800֮�䣬ǰ��λ����Ч�ġ�
  	g_CounterSec=0;
#if 0
	
	eat_gpio_setup(EAT_PIN3_UART1_RTS, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_HIGH);
	eat_gpio_setup(EAT_PIN4_UART1_CTS, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_HIGH);
	eat_gpio_setup(EAT_PIN5_UART1_DCD, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_HIGH);
	eat_gpio_setup(EAT_PIN6_UART1_DTR, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_HIGH);
	eat_gpio_setup(EAT_PIN7_UART1_RI, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_HIGH);

	eat_sleep(5);
	eat_trace("EAT_PIN3_UART1_RTS= %d",eat_gpio_read(EAT_PIN3_UART1_RTS));
	eat_trace("EAT_PIN4_UART1_CTS= %d",eat_gpio_read(EAT_PIN4_UART1_CTS));
	eat_trace("EAT_PIN5_UART1_DCD= %d",eat_gpio_read(EAT_PIN5_UART1_DCD));
	eat_trace("EAT_PIN6_UART1_DTR= %d",eat_gpio_read(EAT_PIN6_UART1_DTR));
	eat_trace("EAT_PIN7_UART1_RI= %d",eat_gpio_read(EAT_PIN7_UART1_RI));
	eat_sleep(5);
	eat_gpio_setup(EAT_PIN3_UART1_RTS, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
	eat_gpio_setup(EAT_PIN4_UART1_CTS, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
	eat_gpio_setup(EAT_PIN5_UART1_DCD, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
	eat_gpio_setup(EAT_PIN6_UART1_DTR, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
	eat_gpio_setup(EAT_PIN7_UART1_RI, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
	
	eat_sleep(5);
	
	eat_trace("EAT_PIN3_UART1_RTS= %d",eat_gpio_read(EAT_PIN3_UART1_RTS));
	eat_trace("EAT_PIN4_UART1_CTS= %d",eat_gpio_read(EAT_PIN4_UART1_CTS));
	eat_trace("EAT_PIN5_UART1_DCD= %d",eat_gpio_read(EAT_PIN5_UART1_DCD));
	eat_trace("EAT_PIN6_UART1_DTR= %d",eat_gpio_read(EAT_PIN6_UART1_DTR));
	eat_trace("EAT_PIN7_UART1_RI= %d",eat_gpio_read(EAT_PIN7_UART1_RI));
	#endif
  	}
  }
		
}

void test_handler_int_level(EatInt_st *interrupt)
{
    eat_trace("test_handler_int_level interrupt->pin [%d ],interrupt->level=%d",interrupt->pin,interrupt->level);
    if(!(interrupt->level))
    {
        //high level trigger,and set low level trigger
       eat_int_set_trigger(interrupt->pin, EAT_INT_TRIGGER_HIGH_LEVEL);
       eat_trace("System interrupt by interrupt->pin [%d ]TRIGGER_LOW_LEVEL",interrupt->pin);
    }
    else
    {
        //low level trigger
        eat_int_set_trigger(interrupt->pin, EAT_INT_TRIGGER_LOW_LEVEL);
        eat_trace("System interrupt by interrupt->pin [%d ] TRIGGER_HIGH_LEVEL",interrupt->pin);        
    }
}
void init_GPIO(void)
{

//��ʼ��io �ж�,�����¼�����Ӧ�ж�
eat_gpio_setup(EAT_PIN6_UART1_DTR, EAT_GPIO_DIR_INPUT, EAT_GPIO_LEVEL_LOW);
if( EAT_GPIO_LEVEL_LOW == eat_gpio_read(EAT_PIN6_UART1_DTR)) 
{   
   eat_trace("EINT PIN%d HIGH LEVEL int test start", EAT_PIN6_UART1_DTR);
   eat_int_setup(EAT_PIN6_UART1_DTR, EAT_INT_TRIGGER_HIGH_LEVEL, 10, NULL);
}
else
{
   eat_trace("EINT PIN%d LOW LEVEL int test start", EAT_PIN6_UART1_DTR);
   eat_int_setup(EAT_PIN6_UART1_DTR, EAT_INT_TRIGGER_LOW_LEVEL, 10, NULL);
}

}
void app_user2(void *data)
{
    EatEvent_st event;
	u32 num;
	//eat_timer_start(EAT_TIMER_3,1000);//1s ��ʱ��ʼ
	init_GPIO();
    while(EAT_TRUE)
    {	eat_sleep(50);
	 //eat_trace("-----app_user2---\n");
	 
	 app_timer3_handler();
	 num= eat_get_event_num_for_user(EAT_USER_2);//������ж�num����numΪ0ʱ����eat_get_event_for_user()���̻߳����
	 if(num>0)
	 	{
        eat_get_event_for_user(EAT_USER_2, &event);
        //eat_trace("EAT_USER_2 MSG id%x", event.event);
		switch(event.event)
        {
            case EAT_EVENT_TIMER ://��ʱ����Ϣ   ID=1
            	//eat_timer_start(EAT_TIMER_3,1*60*1000);
				flag.timer3up=1;
                break;
			case EAT_EVENT_KEY:
				
				break;
            case EAT_EVENT_MDM_READY_RD://EAT�յ�Modem������������ID=4
               	
                break;
            case EAT_EVENT_MDM_READY_WR:
                break;
            case EAT_EVENT_UART_READY_RD:
                
                break;
            case EAT_EVENT_UART_READY_WR:
                
                break;
            case EAT_EVENT_UART_SEND_COMPLETE :
                break;
            case  EAT_EVENT_INT :
				
				test_handler_int_level(&event.data.interrupt);
				break;

            default:
                break;
        }
	 	}
    }
}

