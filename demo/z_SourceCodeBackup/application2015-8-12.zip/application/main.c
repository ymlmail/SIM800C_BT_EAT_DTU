/********************************************************************
 *                Copyright Simcom(shanghai)co. Ltd.                   *
 *---------------------------------------------------------------------
 * FileName      :   main.c
 * version        :   0.10
 * Description   :   
 * Authors       :   maobin
 * Notes          :
 *---------------------------------------------------------------------
 *
 *    HISTORY OF CHANGES
 *---------------------------------------------------------------------
 *0.10  2012-09-24, maobin, create originally.
 *
 *--------------------------------------------------------------------
 * File Description
 * AT+CEAT=parma1,param2
 * param1 param2 
 *   
 *--------------------------------------------------------------------
 ********************************************************************/
 
/********************************************************************
 * Include Files
 ********************************************************************/
#include "platform.h"
#include "app_at_cmd_envelope.h"
#include "app_custom.h"
#include "eat_clib_define.h" //only in main.c
#include "app_sms.h"


#include "App_include.h"//yml add 2015-8-5

/********************************************************************
 * Macros
 ********************************************************************/
#define EAT_MEM_MAX_SIZE 100*1024 

/********************************************************************
 * Types
 ********************************************************************/
typedef struct 
{
    u16 w;  //write offset
    u16 r;  //read offset
    u8  buf[EAT_UART_RX_BUF_LEN_MAX];
}app_buf_st;

typedef void (*app_user_func)(void*);

/********************************************************************
 * Extern Variables (Extern /Global)
 ********************************************************************/

/********************************************************************
 * Local Variables:  STATIC
 ********************************************************************/
static EatEntryPara_st app_para={0};
static u8 s_memPool[EAT_MEM_MAX_SIZE]; 
static app_buf_st modem_rx = {0};
static app_buf_st uart_rx = {0};
 u8 socket_id=0;		//yml 2015-7-28
/********************************************************************
 * External Functions declaration
 ********************************************************************/
extern void APP_InitRegions(void);
extern void app_at_cmd_envelope(void* data);
extern void custom_entry(void);
extern void simcom_sms_read_cb(u16 index,u8* number,u8 *msg);

extern void testGetCrcFunc(void);
extern void LoginMsgPackage(void);//��¼��Ϣ��װ
extern void YML_tcpip_test(u8 param1, u8 param2);
/********************************************************************
 * Local Function declaration
 ********************************************************************/
void app_main(void *data);
void app_func_ext1(void *data);

void Delayms(int time);

eat_bool eat_modem_data_parse(u8* buffer, u16 len, u8* param1, u8* param2);

/********************************************************************
 * Local Function
 ********************************************************************/
#pragma arm section rodata = "APP_CFG"
APP_ENTRY_FLAG 
#pragma arm section rodata

#pragma arm section rodata="APPENTRY"
const EatEntry_st AppEntry = 
{
    app_main,
    app_func_ext1,
    (app_user_func)app_at_cmd_envelope,//app_user1,
    (app_user_func)app_user2,//app_user2,
    (app_user_func)EAT_NULL,//app_user3,
    (app_user_func)EAT_NULL,//app_user4,
    (app_user_func)EAT_NULL,//app_user5,
    (app_user_func)EAT_NULL,//app_user6,
    (app_user_func)EAT_NULL,//app_user7,
    (app_user_func)EAT_NULL,//app_user8,
    EAT_NULL,
    EAT_NULL,
    EAT_NULL,
    EAT_NULL,
    EAT_NULL,
    EAT_NULL
};
#pragma arm section rodata

void app_func_ext1(void *data)
{
/*This function can be called before Task running ,configure the GPIO,uart and etc.
Only these api can be used:
eat_uart_set_debug: set debug port
eat_pin_set_mode: set GPIO mode
eat_uart_set_at_port: set AT port
*/
#if 0
    EatUartConfig_st cfg =
    {
        EAT_UART_BAUD_115200,
        EAT_UART_DATA_BITS_8,
        EAT_UART_STOP_BITS_1,
        EAT_UART_PARITY_NONE
    };

    //2015-7-14 ����
    eat_uart_set_debug(EAT_UART_1);
    eat_uart_set_at_port(EAT_UART_2);// UART1 is as AT PORT

	eat_uart_set_debug_config(EAT_UART_1, &cfg);
	eat_uart_set_debug_config(EAT_UART_2, &cfg);
#else
	eat_uart_set_debug(EAT_UART_USB);
	eat_uart_set_at_port(EAT_UART_1);// UART1 is as AT PORT
	eat_uart_set_debug_config(EAT_UART_DEBUG_MODE_UART, NULL);
	//����USB�������Կڣ���Ҫ��ӡASCIIʱ��Ҫ���������Ҳ������
#endif
eat_modem_set_poweron_urc_dir(EAT_USER_0);//һ��Ĭ�϶���user0   ���ں�core����Ϣ�ظ���EAT_USER_0

}    

static eat_bool app_mem_init(void)
{
    eat_bool ret = EAT_FALSE;
    ret = eat_mem_init(s_memPool,EAT_MEM_MAX_SIZE);
    if (!ret)
    	{
        eat_trace("ERROR: eat memory initial error!");
    	}
	else
		{
		TRACE_DEBUG("yml test msg:eat memory initial OK!\n");
		}
        
    return ret;
}

void app_main(void *data)
{
	 eat_bool result = EAT_TRUE;
    EatEntryPara_st *para;

    APP_InitRegions();//Init app RAM, first step
    APP_init_clib();  //C library initialize, second step

    para = (EatEntryPara_st*)data;
    TRACE_DEBUG("yml delay start111\n");
   // Delayms(5000);
   // TRACE_DEBUG("yml delay end1111\n");
	//eat_sleep_enable(EAT_FALSE);//YML ADD
    memcpy(&app_para, para, sizeof(EatEntryPara_st));
    eat_trace("App Main ENTRY update:%d result:%d", app_para.is_update_app,app_para.update_app_result);
   // if(app_para.is_update_app && app_para.update_app_result)
    {
       // eat_update_app_ok();
    }
	result = eat_get_rtc(&rtc);
            if( result )
            {
                eat_trace("Timer test 1 get rtc value:%d/%d/%d %d:%d:%d",
                        rtc.year,rtc.mon,rtc.day,rtc.hour,rtc.min,rtc.sec);
            }else
            {
                eat_trace("Timer test 1 get rtc fail");
            }
	    rtc.year = 15;
        rtc.mon = 8;
        rtc.day = 10;
        rtc.hour = 9;
        rtc.min = 22;
        rtc.sec = 59;
        //set rtc 
        result = eat_set_rtc(&rtc);
        if( result )
        {
            eat_trace("Timer test 2 rtc set succeed");
        }else
        {
            eat_trace("Timer test 2 rtc set fail");
        }
		result = eat_get_rtc(&rtc);
				if( result )
				{
					eat_trace("Timer test 3 get rtc value:%d/%d/%d %d:%d:%d",
							rtc.year,rtc.mon,rtc.day,rtc.hour,rtc.min,rtc.sec);
				}else
				{
					eat_trace("Timer test 3 get rtc fail");
				}

    custom_entry();
}

/*Read the data from UART */
static void uart_rx_proc(const EatEvent_st* event)
{
    u16 len;
    EatUart_enum uart = event->data.uart.uart;
    app_buf_st* rx_p = (app_buf_st*)&uart_rx;

    do
    {
        if(rx_p->w == EAT_UART_RX_BUF_LEN_MAX)
        {
             rx_p->w = 0;
             rx_p->r = 0;
        } 
        len = eat_uart_read(uart, &rx_p->buf[rx_p->w], EAT_UART_RX_BUF_LEN_MAX-rx_p->w);
        if(len>0)
        {
            rx_p->w += len;  
        }
    }while(len > 0);

    eat_trace("Uart buf w=%d r=%d",rx_p->w, rx_p->r);
}

/*Read the data from Modem*/
static void mdm_rx_proc(void)
{
    u16 len;
    u16 w_len;
    app_buf_st* rx_p = (app_buf_st*)&modem_rx;
    do
    {
        len = eat_modem_read(&rx_p->buf[rx_p->w], EAT_UART_RX_BUF_LEN_MAX-rx_p->w);
        if(len==0)
        {
            break;
        }
        
        if(len>0)
        {
            rx_p->w += len;
            len = rx_p->w - rx_p->r;
            w_len = eat_uart_write(eat_uart_app, &rx_p->buf[rx_p->r], len);
            //The buffer is full, the remainder data in Modem will be process in EVENT EAT_EVENT_UART_READY_WR
            if(w_len<len)
            {
                rx_p->r += w_len;
               break;
            }else
            {
                rx_p->r = 0;
                rx_p->w = 0;
            }
        }
    }while(1 );
}

/*process the EAT_EVENT_UART_READY_WR, continues to write the data of Modem to UART*/
static void uart_ready_wr_proc(void)
{
    u16 len;
    u16 w_len;
    app_buf_st* rx_p = (app_buf_st*)&modem_rx;
    
    len = rx_p->w-rx_p->r;
    w_len = eat_uart_write(eat_uart_app, &rx_p->buf[rx_p->r], len);
    if( w_len < len)
    {
        rx_p->r += len;
        return;
    }else
    {
        rx_p->r = 0;
        rx_p->w = 0;
    }
    
    do
    {
        len = eat_modem_read(&rx_p->buf[rx_p->w], EAT_UART_RX_BUF_LEN_MAX-rx_p->w);
        if(len==0)
        {
            break;
        }
        if(len>0)
        {
            rx_p->w += len;
            len = rx_p->w - rx_p->r;
            w_len = eat_uart_write(eat_uart_app, &rx_p->buf[rx_p->r], len);
            if(w_len<len)
            {
               rx_p->r += w_len;
               //The eat uart buffer is full, the remainder data in Modem will be process in EVENT EAT_EVENT_UART_READY_WR
               break;
            }else
            {
                rx_p->r = 0;
                rx_p->w = 0;
            }
        }
    }while(1);
}

eat_bool app_uart_init(void)
{
    eat_bool result = EAT_FALSE;
    EatUartConfig_st uart_config;
    if(eat_uart_open(eat_uart_app ) == TRUE)
    {
        if( EAT_UART_USB != eat_uart_app )//usb port not need to config
        {
            uart_config.baud = EAT_UART_BAUD_115200;
            uart_config.dataBits = EAT_UART_DATA_BITS_8;
            uart_config.parity = EAT_UART_PARITY_NONE;
            uart_config.stopBits = EAT_UART_STOP_BITS_1;
            if(EAT_TRUE == eat_uart_set_config(eat_uart_app, &uart_config))
            {
                result = EAT_TRUE;
            }else
            {
                eat_trace("[%s] uart(%d) set config fail!", __FUNCTION__, eat_uart_app);
            }
            //eat_uart_set_send_complete_event(eat_uart_app, EAT_TRUE);
        }
    }else
    {
        eat_trace("[%s] uart(%d) open fail!", __FUNCTION__, eat_uart_app);
    }
    
    return result;
}

void custom_entry(void)
{
	u8 cgatt = 0;
	u8 creg=0;
	u8 i=0;
	u32 num;//,num1;

    EatEvent_st event;
 
   // app_mem_init();  //Memory
   // app_uart_init(); //UART
	//GlobalVariableInit();
	//TRACE_DEBUG("yemaolin VISION %s %s\n",__DATE__,__TIME__);
   // eat_trace("%s-%d: custom_entry\n", __FILE__, __LINE__);

   // eat_uart_write(eat_uart_app,"\r\nAPP entry!\r\nVersion:1\r\n",25);
/*
	while(1)
{
	//testGetCrcFunc();
	
	LoginMsgPackage();//��¼��Ϣ��װ,����ok
	Delayms(1000);

}*/
	//eat_get_versio();
	//eat_trace("Core version=%s",eat_get_version());
	//eat_trace("Core buildtime=%s",eat_get_buildtime());
	//eat_trace("Core buildno=%s",eat_get_buildno());	
	//eat_trace("eat_get_imei=%s",eat_get_imei(g_imei_sn,16));
	//eat_trace("imei string=%s\n",g_imei_sn);
	//for(i=0;i<16;i++)
		//{eat_trace("%2d",g_imei_sn[i]);}
	
	//LBSPackage();//�ϱ�LBS��Ϣ
	StatePackage();
   
	/*
while(cgatt==0)
{
	cgatt = eat_network_get_cgatt();
	eat_trace("cgatt =%d", cgatt);
}
while(1)
{
creg=eat_network_get_creg();
if(creg==1)
{
eat_trace("cgatt =%d", cgatt);
break;
}
eat_sleep(100);	
}*/
	//Delayms(3000);
	//SetCregValue();
	//SetCENGValue();
   	//simcom_gsm_init("1234",GsmInitCallback);
    simcom_sms_init();
	eat_sleep(200);
	eat_trace("entry while true\n");
	

    while(EAT_TRUE)
    {	//eat_sleep_enable(EAT_FALSE);
    	//eat_sleep(10);
    	//AppLogicHandle();
		
		//SendAtComHandle();
		
		eat_trace("++++main+++");
		eat_sleep(50);
			num = eat_get_event_num();
		//get_event:
		if(num>0)
		{
		eat_trace("num=%d\n", num);
        eat_get_event(&event);
        eat_trace("MSG id%x", event.event);
	#if 1
        switch(event.event)
        {
            case EAT_EVENT_TIMER ://��ʱ����Ϣ   ID=1
                break;
			case EAT_EVENT_KEY:
				flag.askLBSmsg=1;
				break;
            case EAT_EVENT_MDM_READY_RD://EAT�յ�Modem������������ID=4
               	{
                   mdm_rx_proc();
                }
                break;
            case EAT_EVENT_MDM_READY_WR:
                break;
            case EAT_EVENT_UART_READY_RD:
                uart_rx_proc(&event);
                break;
            case EAT_EVENT_UART_READY_WR:
                uart_ready_wr_proc();
                break;
            case EAT_EVENT_UART_SEND_COMPLETE :
                break;
            case  EAT_EVENT_INT :
				break;

            default:
                break;
        }
		#endif
	}
    }
}

void Delayms(int time)
{
int i,j;
for(i=0;i<time;i++)
	for(j=0;j<10000;j++);
		
}

eat_bool eat_modem_data_parse(u8* buffer, u16 len, u8* param1, u8* param2)
{
    eat_bool ret_val = EAT_FALSE;
    u8* buf_ptr = NULL;
    /*param:%d,extern_param:%d*/
     buf_ptr = (u8*)strstr((const char *)buffer,"param");
    if( buf_ptr != NULL)
    {
        sscanf((const char *)buf_ptr, "param:%d,extern_param:%d",(int*)param1, (int*)param2);
        eat_trace("data parse param1:%d param2:%d",*param1, *param2);
        ret_val = EAT_TRUE;
    }
    return ret_val;
}

