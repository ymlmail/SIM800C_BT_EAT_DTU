#ifndef _APP_INCLUDE_H_
#define _APP_INCLUDE_H_

#include "Platform.h"
#include "App_macro.h"

#include "app_init.h"
#include "App_ram.h"

#include "user_communication.h"
#include "App_logic.h"








#endif
