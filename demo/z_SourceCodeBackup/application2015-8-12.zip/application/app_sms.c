/********************************************************************
 *                Copyright Simcom(shanghai)co. Ltd.                   *
 *---------------------------------------------------------------------
 * FileName      :   app_sms.c
 * version       :   0.10
 * Description   :   
 * Authors       :   heweijiang
 * Notes         :
 *---------------------------------------------------------------------
 *
 *    HISTORY OF CHANGES
 *
 *0.10  2014-06-11, heweijiang, create originally.
 *---------------------------------------------------------------------
 *
 *1. Before using the SMS service,please call simcom_sms_init().
 *2. Use eat_get_sms_ready_state() to confirm SMS service is available or not.
 *3. About SMS APT useage,please refer to the API description in eat_sms.h
 *
 ********************************************************************/
/********************************************************************
 * Include Files
 ********************************************************************/
 
#include <string.h>
#include "eat_sms.h"
#include "eat_interface.h"
#include "platform.h"
#include "app_custom.h"


#include <stdio.h>
#include <string.h>
#include "eat_modem.h"
//#include "eat_interface.h"
#include "eat_uart.h"
//#include "eat_sms.h"

//#include "eat_clib_define.h" //only in main.c

/********************************************************************
* Macros
 ********************************************************************/
 #define EAT_SMSAL_MAX_TPDU_SIZE         (175)
#define EAT_MAX_DIGITS_USSD          183
#define EAT_RMMI_IS_LOWER( alpha_char )   \
	  ( ( (alpha_char >= 'a') && (alpha_char <= 'z') ) ?  1 : 0 )
	
#define EAT_RMMI_IS_NUMBER( alpha_char )   \
	   ( ( (alpha_char >= '0') && (alpha_char <= '9') ) ? 1 : 0 )

/********************************************************************
* Types
 ********************************************************************/

/********************************************************************
* Extern Variables (Extern /Global)
 ********************************************************************/
extern SIMCOM_SMS_INFO g_sms_info;
/********************************************************************
* Local Variables:  STATIC
 ********************************************************************/

/********************************************************************
* External Functions declaration
 ********************************************************************/

/********************************************************************
* Local Function declaration
 ********************************************************************/
eat_bool simcom_sms_msg_read(u16 index);
void simcom_sms_setting(void);
 
/********************************************************************
* Local Function
 ********************************************************************/

/*new sms message callback function*/
static eat_sms_new_message_cb(EatSmsNewMessageInd_st smsNewMessage)
{
    eat_trace("eat_sms_new_message_cb, storage=%d,index=%d",smsNewMessage.storage,smsNewMessage.index);

    simcom_sms_msg_read(smsNewMessage.index); //��ȡ��index������
}

/*receive flash sms message callback function*/
static eat_sms_flash_message_cb(EatSmsReadCnf_st smsFlashMessage)
{
    u8 format =0;

    eat_get_sms_format(&format);
    eat_trace("eat_sms_flash_message_cb, format=%d",format);
    if(1 == format)//TEXT mode
    {
        eat_trace("1eat_sms_read_cb, msg=%s",smsFlashMessage.data);
        eat_trace("2eat_sms_read_cb, datetime=%s",smsFlashMessage.datetime);
        eat_trace("3eat_sms_read_cb, name=%s",smsFlashMessage.name);
        eat_trace("4eat_sms_read_cb, status=%d",smsFlashMessage.status);
        eat_trace("5eat_sms_read_cb, len=%d",smsFlashMessage.len);
        eat_trace("6eat_sms_read_cb, number=%s",smsFlashMessage.number);
    }
    else//PDU mode
    {
        eat_trace("7eat_sms_read_cb, msg=%s",smsFlashMessage.data);
        eat_trace("8eat_sms_read_cb, len=%d",smsFlashMessage.len);
    }
}

/*send sms message callback function*/
static void eat_sms_send_cb(eat_bool result)
{
    eat_trace("eat_sms_send_cb, result=%d",result);
}


/*sms ready callback function*/
static void eat_sms_ready_cb(eat_bool result)
{

    if (TRUE == result)
    {
        //SMS Ready, SMS example entry
        eat_trace("SMS Ready");
       // simcom_sms_setting();		//yml 2015-7-17  disable
    }    
    else
    {
        eat_trace("SMS Not Ready");
    }
}

/*SMS service init, register callback function*/
void simcom_sms_init(void)
{
    eat_set_sms_operation_mode(EAT_TRUE);//sms ����API����ģʽ
    eat_sms_register_new_message_callback(eat_sms_new_message_cb);
    eat_sms_register_flash_message_callback(eat_sms_flash_message_cb);
    eat_sms_register_send_completed_callback(eat_sms_send_cb);
    eat_sms_register_sms_ready_callback(eat_sms_ready_cb);
}

/********************************************************************
 * SMS PROCESS FUNCTION 
 *******************************************************************/
eat_bool simcom_sms_send(u8* number, u8* msg, u16 msgLen)
{
    
    if(NULL == number){
        return EAT_FALSE;
    }

    if(msgLen > 160){
        return EAT_FALSE;
    }

    eat_trace("simcom_sms_msg_send number=%s, msg=%s", number,msg);

    eat_set_sms_format(g_sms_info.formatType);  //text format
    eat_send_text_sms(number,msg);

    return EAT_TRUE;
}

eat_bool simcom_sms_sc_set(u8* number)
{
    if(NULL == number){
        return FALSE;
    }

    eat_trace("simcom_sms_sc_set Number=%s",number);

    return eat_set_sms_sc(number);
}

eat_bool simcom_sms_format_set(u8 nFormatType)
{
    eat_trace("simcom_sms_format_set FormatType=%d", nFormatType);

    return eat_set_sms_format(nFormatType);
}

eat_bool simcom_sms_cnmi_set(u8 mt)
{
    eat_trace("simcom_sms_cnmi_set %d", mt);
    
    return eat_set_sms_cnmi(2,mt,0,0,0);
}
//2015-8-3 add
/*****************************************************************************
 * FUNCTION
 *  EatToUpper
 * DESCRIPTION
 *  
 * PARAMETERS
 *  str     [?]     
 * RETURNS
 *  void
 *****************************************************************************/
void EatToUpper(u8 *str)
{
    u8 *ptr;

    if(str == NULL)
    {
        eat_trace("EatToUpper(),failed");
        return ;
    }
    //ASSERT(str != NULL);
    ptr = str;
    while (*ptr != 0)
    {
        if (EAT_RMMI_IS_LOWER(*ptr))
        {
            *ptr += 'A' - 'a';
        }
        ptr++;
    }
}


/*****************************************************************************
 * FUNCTION
 *  eat_check_sms_pdu_string
 * DESCRIPTION
 *  
 * PARAMETERS
 *  length      [IN]        
 *  bytes       [?]         
 *  str         [?]         
 * RETURNS
 *  void
 *****************************************************************************/
void eat_check_sms_pdu_string(u16 length, u8 *bytes, u8 *str)
{
    u16 i = 0;
    u16 j = 0;
  
    if((str == NULL) || (bytes == NULL))
    {
        eat_trace("eat_check_sms_pdu_string() failed");
        return;    
    }
    
    while (i < length)
    {
        j += sprintf((char*)str + j, "%02x", bytes[i]);
        i++;
    }
    str[j] = 0;
    EatToUpper(str);
}

eat_bool decodePDU(u8* ptr)
{
#if 0
eat_bool ret = 0;
u8 len = 0;//strlen(ptr);
EatSmsalPduDecode_st sms_pdu = {0};
u8 useData[320] = {0};
u8 useLen = 0;
u8 phoneNum[43] = {0};

eat_trace("eat_sms_decode_tpdu_core, ptr = %s,len = %d",ptr,len);
ret = eat_sms_decode_tpdu(ptr, len, &sms_pdu);
eat_trace("eat_sms_decode_tpdu_core, ret = %d",ret );
useLen = sms_pdu.tpdu.data.deliver_tpdu.user_data_len;
//�Ѷ�������ת����ӡ����
eat_check_sms_pdu_string(useLen,sms_pdu.tpdu.data.deliver_tpdu.user_data,useData);
eat_trace("simcom_sms_decode_pdu(), user data len (%d)",useLen);
eat_trace("simcom_sms_decode_pdu(), user data(%s)",useData);

eat_trace("yml testPDU\n");
#endif
#if 1
	eat_bool ret = 0;
	//u8 ptr[]= "0891683108200105F0040D91683186613767F20000413012516585230631D98C56B301";
	u8 len = 0;//strlen(ptr);
	EatSmsalPduDecode_st sms_pdu = {0};
	u8 useData[320] = {0};
	u8 useLen = 0;
	u8 phoneNum[43] = {0};
	
	eat_trace("eat_sms_decode_tpdu_core, ptr = %s,len = %d",ptr,len);
	ret = eat_sms_decode_tpdu(ptr, len, &sms_pdu);
	eat_trace("eat_sms_decode_tpdu_core, ret = %d",ret );
	
	useLen = sms_pdu.tpdu.data.deliver_tpdu.user_data_len;
	//�Ѷ�������ת����ӡ����
	eat_check_sms_pdu_string(useLen,sms_pdu.tpdu.data.deliver_tpdu.user_data,useData);
	eat_trace("simcom_sms_decode_pdu(), user data len (%d)",useLen);
	eat_trace("simcom_sms_decode_pdu(), user data(%s)",useData);
	
	eat_sms_orig_address_data_convert(sms_pdu.tpdu.data.deliver_tpdu.orig_addr, phoneNum);
	eat_trace("simcom_sms_decode_pdu(), phone Num(%s)",phoneNum);
#endif
}

static void eat_sms_read_cb(EatSmsReadCnf_st  smsReadCnfContent)
{
    u8 format =0;

    eat_get_sms_format(&format);
    eat_trace("eat_sms_read_cb, format=%d",format);
    if(1 == format)//TEXT mode
    {
        eat_trace("eat_sms_read_cb, msg=%s",smsReadCnfContent.data);
        eat_trace("eat_sms_read_cb, datetime=%s",smsReadCnfContent.datetime);
        eat_trace("eat_sms_read_cb, name=%s",smsReadCnfContent.name);
        eat_trace("eat_sms_read_cb, status=%d",smsReadCnfContent.status);
        eat_trace("eat_sms_read_cb, len=%d",smsReadCnfContent.len);
        eat_trace("eat_sms_read_cb, number=%s",smsReadCnfContent.number);
    }
    else//PDU mode
    {
        eat_trace("eat_sms_read_cb, msg=%s",smsReadCnfContent.data);
        eat_trace("eat_sms_read_cb, name=%s",smsReadCnfContent.name);
        eat_trace("eat_sms_read_cb, status=%d",smsReadCnfContent.status);
        eat_trace("eat_sms_read_cb, len=%d",smsReadCnfContent.len);

		//decodePDU(smsReadCnfContent.data);
    }
}

eat_bool simcom_sms_msg_read(u16 index)
{    
    eat_trace("simcom_sms_msg_read index = %d", index);

    return eat_read_sms(index,eat_sms_read_cb);
}

static void eat_sms_delete_cb(eat_bool result)
{
    eat_trace("eat_sms_delete_cb, result=%d",result);
}

eat_bool simcom_sms_msg_delete(u16 index)
{
    eat_trace("simcom_sms_msg_delete index = %d", index);

    return eat_delete_sms(index,eat_sms_delete_cb);
}

void simcom_sms_setting(void)
{    
    if(TRUE == eat_get_sms_ready_state())//�ڷ��Ͷ���֮ǰ����ȷ�϶���ģ���״̬�Ƿ�������
    {   
        simcom_sms_format_set(g_sms_info.formatType);
        simcom_sms_cnmi_set(g_sms_info.mt);
        simcom_sms_send((u8 *)g_sms_info.phone_number,(u8 *)g_sms_info.sms_string,g_sms_info.msg_len);
    }
    else
    {
        eat_trace("SMS Not Ready");
    }
}
