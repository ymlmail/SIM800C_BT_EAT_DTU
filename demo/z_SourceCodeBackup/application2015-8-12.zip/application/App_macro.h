//yemaolin Creat 2015-7-29

#define DebugMsgOnOff		1

#define UsbAsPort			0


#define SeverDataMax		100






