#ifndef _APP_RAM_H
#define _APP_RAM_H
//�ṹ�嶨��
#include "Platform.h"


#define MobileCountryCode   460U//ʮ������Ϊ0X01CC

//�ṹ�嶨��

typedef union T_UNION
{
    u8 Byte;
    struct
    {
        u8 B0:1;
        u8 B1:1;
        u8 B2:1;
        u8 B3:1;
        u8 B4:1;
        u8 B5:1;
        u8 B6:1;
        u8 B7:1;
    } Bit;
} T_UNION;

typedef struct
{
    u8 timer1up:1;
    u8 recvSeverData:1;
    u8 LoginOK:1;
    u8 :1;
    u8 :1;
    u8 reportLBSmsgOK:1;
    u8 LBSmsgReady:1;
    u8 askLBSmsg:1;

	u8 GPSisOk:1;
	u8 :1;
	u8 :1;
	u8 :1;
	u8 :1;
	u8 :1;
	u8 :1;
	u8 timer3up:1;
	
}T_FLAG;


typedef struct{

    u8 phonetime:1;
    u8 :1;
    u8 :1;
    u8 :1;
    u8 :1;
    u8 :1;
    u8 :1;
    u8 :1;

}T_DELAY;

typedef struct
{
	u8  key1 :1;
	u8  key2 :1;
	u8  key3 :1;
	u8  key4 :1;
	u8  key5 :1;
	u8  key6 :1;
	u8  key7 :1;
	u8  key8 :1;
}T_KEY;
typedef enum
{
	LoginMsgNUM=0x01,
	GPSMsgNUM=0x10,
	LBSMsgNUM=0x11,
	StateMsgNUM=0x13,
	GPS_LBS_STATE_MsgNUM=0x16,
	LBS_TelPhoneNumber_NUM=0x17,
	LBS_ExpandMsgNUM=0x18,
	LBS_StateMsgNUM=0x19,
	GPS_TelPhoneNumber_NUM=0x1A,
	ServerEleFenceElarmAddrNUM=0x1B,
	TimerSyncMsgNUM=0x1F,
	ServerToTerminalCMD=0x80,
	TerminalToServer=0x81,
	
}ProtocolNumberType;

typedef union {	
	u8 logoinArry[22];
 struct __PACKED
{
    u16 start;			//��ʼλ
    u8 len;  			//����
    
    u8 ProtocolNumber;	//Э���
	u8 terminal_ID[8];	//�ն˺�
	u16 TypeCode;		//ʶ���룬�ն�
	u16 expand;			//��չ��
	
	u16 MsgSN;			//���к�
	u16 CRC;			//CRCУ��
	u16 end;			//����λ
 }pkg;
}Info_Logoin;


extern u16 GetCrc16(const u8* pData, int nLength);
extern Info_Logoin logoinInfo;

extern T_FLAG  flag;
extern T_DELAY delay;
extern T_KEY   key;
extern u8 buf[2048];
extern u8 g_imei_sn[16];
extern u8 g_RecvServerData[100];
extern u8 g_RecvServerDataLen;

extern u8 g_CounterSec;

typedef union {	
	u8 LBSArry[26];
 struct __PACKEDlbs
{
    u16 start;			//��ʼλ
    u8 len; 			//����
    u8 ProtocolNumber;	//Э���
	u8 year;	//��
	u8 month;		//��
	u8 day;			//��
	u8 hour;			//ʱ
	u8 minute;			//��
	u8 second;			//��
	u16 MCC;			//�й��ƶ����Һ�
	u8 MNC;// �ƶ������mobile network code
	u8 LAC0;			// λ������
	u8 LAC1;
	u8 CI0;
	u8 CI1;
	u8 CI2;
	u8 expand0;
	u8 expand1;
	//u16 expand;			//��չ��
	u8 MsgSN0;			//���к�
	u8 MsgSN1;			//���к�
	u16 CRC;			//CRCУ��
	u16 end;			//����λ
 }pkg;
}Info_LBS;


typedef union {	
	u16 LAC;
 struct 
{
	u8 LAC1;
	u8 LAC0;
 }pkg;
}LAC_TYPE;

typedef union {	
	u16 CI;
 struct 
{
	u8 CI3;
	u8 CI2;
	u8 CI1;
	u8 CI0;
 }pkg;
}CI_TYPE;


extern Info_LBS LBSmsg;
extern Info_Logoin logoinInfo;
extern EatRtc_st rtc;



extern LAC_TYPE LocationAreaCode;
extern CI_TYPE CellID;
extern u8	g_MobileNetworkCode;
extern u16 g_loginMsgSn;
extern u8 g_sendDataArry[200];

#endif

