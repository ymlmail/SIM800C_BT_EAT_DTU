/********************************************************************
 *                Copyright Simcom(shanghai)co. Ltd.                   *
 *---------------------------------------------------------------------
 * FileName      :  app_custom.c
 * version       :   0.10
 * Description   :   
 * Authors       :   heweijiang
 * Notes         :
 *---------------------------------------------------------------------
 *
 *    HISTORY OF CHANGES
 *---------------------------------------------------------------------
 *0.10  2014-07-11, heweijiang, create originally.
 *
 ********************************************************************/
/********************************************************************
 * Include Files
 ********************************************************************/
#include "app_custom.h"
#include "App_include.h"

/********************************************************************
* Macros
 ********************************************************************/

/********************************************************************
* Types
 ********************************************************************/
 
/********************************************************************
* Extern Variables (Extern /Global)
 ********************************************************************/

/*Customer configuration*/
ModemConfigContext g_modemConfig =
{
    "CMET",             /*apnName*/
    "",                 /*apnUserName*/
    "",                 /*apnPassword*/
    "116.247.119.165",  /*FTPServerIP*/
    "admin",            /*FTPUserName*/
    "password",         /*FTPPassword*/
    "filename",         /*FTPFileName*/
    "/",                /*FTPFilePath*/
    21,                 /*FTPPort*/
};

const SIMCOM_SMS_INFO g_sms_info = 
{
    TEXT,			//TEXTģʽֻ�ܷ��ַ������ܷ�����????
    "",             //sc number
    "13320984483",  //phone number
    "0123456789jason",   //message string
    15,             //message length
    1
};
/*
const SIMCOM_SMS_INFO g_sms_info = 
{
    PDU,
    "",             //sc number
    "13320984483",  //phone number
    "01Ҷï��00",   //message string
    10,             //message length
    1
};*/

/********************************************************************
* Local Variables:  STATIC
 ********************************************************************/

/********************************************************************
* External Functions declaration
 ********************************************************************/

/********************************************************************
* Local Function declaration
 ********************************************************************/
 
/********************************************************************
* Local Function
 ********************************************************************/
    
void GsmInitCallback(eat_bool result)
{
    if (result)
    {
        //GSM Init ok, to do something. 
        eat_trace("GSM init OK\r\n",14);
        simcom_tcpip_test();
    }
    else
    {
        eat_trace("GSM init ERROR\r\n",14);        
    }
}

void askCregCallback(eat_bool result)
{
    if (result)
    {
        //GSM Init ok, to do something. 
        eat_trace("1212121\r\n",14);
    }
    else
    {
        eat_trace("@@@@@@@@\r\n",14);        
    }
}
static void app_timer3_handler(void)
{
  if(flag.timer3up)
  	{
  	flag.timer3up=0;
  	g_CounterSec++;
  if(g_CounterSec>=20)
  	{
	TRACE_DEBUG("g_CounterSec=%d",g_CounterSec);
  	g_CounterSec=0;
  	}
  	}
		
}

void app_user2(void *data)
{
    EatEvent_st event;
	u32 num;
	eat_timer_start(EAT_TIMER_3,1000);//1s ��ʱ��ʼ
    while(EAT_TRUE)
    {	eat_sleep(50);
	 //eat_trace("-----app_user2---\n");
	 
	 app_timer3_handler();
	 num= eat_get_event_num_for_user(EAT_USER_2);//������ж�num����numΪ0ʱ����eat_get_event_for_user()���̻߳����
	 if(num>0)
	 	{
        eat_get_event_for_user(EAT_USER_2, &event);
        //eat_trace("EAT_USER_2 MSG id%x", event.event);
		switch(event.event)
        {
            case EAT_EVENT_TIMER ://��ʱ����Ϣ   ID=1
            	eat_timer_start(EAT_TIMER_3,1000);
				flag.timer3up=1;
                break;
			case EAT_EVENT_KEY:
				
				break;
            case EAT_EVENT_MDM_READY_RD://EAT�յ�Modem������������ID=4
               	
                break;
            case EAT_EVENT_MDM_READY_WR:
                break;
            case EAT_EVENT_UART_READY_RD:
                
                break;
            case EAT_EVENT_UART_READY_WR:
                
                break;
            case EAT_EVENT_UART_SEND_COMPLETE :
                break;
            case  EAT_EVENT_INT :
				break;

            default:
                break;
        }
	 	}
    }
}

