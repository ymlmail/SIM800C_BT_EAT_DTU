#ifndef _USER_COMMUNICATION_H_
#define _USER_COMMUNICATION_H_

#include "platform.h"
typedef enum
{
	LoginMsgNUM=0x01,
	GPSMsgNUM=0x10,
	LBSMsgNUM=0x11,
	StateMsgNUM=0x13,
	GPS_LBS_STATE_MsgNUM=0x16,
	LBS_TelPhoneNumber_NUM=0x17,
	LBS_ExpandMsgNUM=0x18,
	LBS_StateMsgNUM=0x19,
	GPS_TelPhoneNumber_NUM=0x1A,
	ServerEleFenceElarmAddrNUM=0x1B,
	TimerSyncMsgNUM=0x1F,
	ServerToTerminalCMD=0x80,
	TerminalToServer=0x81,
	
}ProtocolNumberType;

typedef union {	
	u8 logoinArry[22];
 struct __PACKED
{
    u16 start;			//��ʼλ
    u8 len;  			//����
    
    u8 ProtocolNumber;	//Э���
	u8 terminal_ID[8];	//�ն˺�
	u16 TypeCode;		//ʶ���룬�ն�
	u16 expand;			//��չ��
	
	u16 MsgSN;			//���к�
	u16 CRC;			//CRCУ��
	u16 end;			//����λ
 }pkg;
}Info_Logoin;

extern u16 GetCrc16(const u8* pData, int nLength);
extern Info_Logoin logoinInfo;
extern void LoginMsgPackage(void);//��¼��Ϣ��װ
#endif
