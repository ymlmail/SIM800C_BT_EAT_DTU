#ifndef _APP_RAM_C
#define _APP_RAM_C
#include "App_ram.h"

T_FLAG  flag;
T_DELAY delay;
T_KEY   key;

u8 buf[2048];


#endif
