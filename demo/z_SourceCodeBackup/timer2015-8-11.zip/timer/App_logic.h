
//yemaolin creat 2015-7-30
#ifndef __APP_LOGIC_H__
#define __APP_LOGIC_H__
#include "App_include.h"

extern void AppGetEventHandle(void);
extern void AppLogicHandle(void);


#endif


