EAT APP demo:
    Function:SMS,TCPIP,FTP,FOTA
